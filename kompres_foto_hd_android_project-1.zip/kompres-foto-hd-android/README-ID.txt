KOMPRES FOTO HD — PROYEK ANDROID

Isi proyek ini adalah sumber aplikasi Android, BUKAN file APK yang sudah jadi.
Aplikasi membungkus aplikasi kompres foto HTML dalam Android WebView.
Pemilihan foto ditangani oleh pemilih file native Android melalui WebChromeClient.

Cara menghasilkan APK tanpa Android Studio:
1. Buat repository baru di GitHub.
2. Ekstrak seluruh isi ZIP ini, lalu unggah semua file dan folder ke repository.
3. Buka tab Actions di repository GitHub.
4. Jalankan workflow "Build APK" (Run workflow), atau tunggu workflow berjalan setelah push.
5. Buka hasil workflow yang berhasil, lalu unduh artifact bernama "kompres-foto-hd-apk".
6. Ekstrak artifact dan pasang app-debug.apk di HP Android.
   Jika diminta, izinkan instalasi aplikasi dari sumber tersebut.

Catatan:
- APK debug cocok untuk instalasi dan pengujian pribadi.
- Ini belum merupakan APK release yang ditandatangani untuk distribusi Play Store.
- Minimum Android yang ditargetkan: Android 6.0 (API 23).
- Foto diproses lokal pada perangkat; tidak diunggah ke server.
